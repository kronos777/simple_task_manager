<?php

/**
 * Get remote data and save new task
 */
if ( isset( $_POST['updateData'] ) ) {
    //get info && save info

    ZISWP_getRemoteData();

}